package bingo.run;

public class Main {

	public static void main(String[] args) {
		new Server();	// 서버 실행
		
	}

}
