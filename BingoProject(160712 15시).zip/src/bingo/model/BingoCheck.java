package bingo.model;

public class BingoCheck {

}
