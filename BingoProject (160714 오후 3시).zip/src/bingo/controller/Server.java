package bingo.controller;

import java.util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.*;
import java.net.*;

import bingo.model.BingoCheck;
import bingo.model.User;

public class Server extends JFrame implements ActionListener{
	TextArea txt_list;
	JButton btn_exit;
	//HashMap<String, User> users;
	Vector userCount;

	public Server(){
		super("Bingo Server");

		txt_list = new TextArea();
		btn_exit = new JButton("서버종료");

		add(txt_list, "Center");
		add(btn_exit,"South");
		setSize(500,500);
		setVisible(true);

		//이벤트처리-----------------------
		addWindowListener(
				new WindowAdapter(){
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				}
				);
		btn_exit.addActionListener(this);
		//-----------------------------------------------------
		userCount = new Vector();            //반드시 ServerStart()보다 먼저기술
		ServerSocket();
	}
	//=====================서           버=========================
	public void ServerSocket()
	{
		final int port=8000;
		try{
			ServerSocket ss = new ServerSocket(port);            //접속대기중
			while(true)
			{
				System.out.println("클라이언트 접속 대기중...");
				Socket client = ss.accept();                          //요청수락
				String str = client.getInetAddress().getHostAddress();   //ip주소 받기
				System.out.println(client.getInetAddress().getHostAddress() + "연결완료!");
				txt_list.append(str + "에서 접속!!");                                           //들어온객체추가

				//병행처리를 하기위한 Client객체를 생성(사용자정의클래스)-------
				BingoHandler ch = new BingoHandler(this,client);
				userCount.addElement(ch);           //객체추가(인원수)
				ch.start();

			}
		}catch(Exception e){
			System.out.println("클라이언트 종료");
		}
	}
	
	public void setMsg(String msg)  //txt_list에  nickname or 대화내용을 출력
	{
		txt_list.append(msg+"\n");
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btn_exit)
			System.exit(0);
	}	
	
	/*public static void main(String[] args) {
		new Server();
	}*/
	
	
}