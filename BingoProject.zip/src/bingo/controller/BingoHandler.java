package bingo.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import bingo.run.Server;

public class BingoHandler extends Thread{
	//Field
	private Server server;
	private Socket socket;
	private BufferedReader br;
	private PrintWriter pw;

	//Constructor
	public BingoHandler(Server server, Socket socket)
	{
		this.server = server;
		this.socket = socket;
		try{
			InputStream is = socket.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));	//입력스트림

			OutputStream os = socket.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));	//출력스트림
			
			
		}catch(Exception e){}
	}
	
	//Method
	
	//Thread start시 작동 함수
	public void run()
	{
		String nickname=null;
		try{
			nickname = br.readLine();    
			server.setMsg("[" + nickname +"]님이 입장하셨습니다");
			sendAll("[" + nickname +"]님이 입장하셨습니다");
			
			if(server.getUserCount().size() == 1){
				System.out.println(String.valueOf(server.getUserCount().size())+"명");
				pw.println(String.valueOf(server.getUserCount().size())+"명");
				pw.flush();
			}
			else{
				pw.println(String.valueOf(server.getUserCount().size())+"명");
				pw.flush();
				sendAll(String.valueOf(server.getUserCount().size())+"명");
			}
			sendTurn();
			
			while(true){  //대화중시작
				
				String text = br.readLine();
				server.setMsg(nickname + " : " + text + "선택");
				sendAll(text);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			synchronized(server.getUserCount()){

				server.setMsg("[" + nickname +"]님이 퇴장하셨습니다");
				sendAll("[" + nickname +"]님이 퇴장하셨습니다");
				server.getUserCount().removeElement(this);
				if(server.getUserCount().size() < 2)
					sendAll("상대방이 나가 게임을 종료합니다.");
			}
		}
	}
	
	//클라이언트에게 선공인지 후공인지 알려주는 메소드
	public void sendTurn() {
		synchronized(server.getUserCount()){
			int s = server.getUserCount().size();        //인원수체크
			if(s > 1){
				for(int i=0; i<s; i++)
				{
					if(i==0){	//첫번째로 접속한 사람이 선공
						BingoHandler data = (BingoHandler)server.getUserCount().elementAt(i);
						data.pw.println("선공");
						data.pw.flush();
					}else if(this.equals(server.getUserCount().elementAt(i))){
						BingoHandler data = (BingoHandler)server.getUserCount().elementAt(i);
						data.pw.println("후공");
						data.pw.flush();
					}
				}
			}
		}
	}
	
	//모든접속자에게 메세지를 보내는 메소드
	public void sendAll(String message)
	{
		synchronized(server.getUserCount()){
			int s = server.getUserCount().size();        //인원수체크

			for(int i=0; i<s; i++)
			{
				if(!this.equals(server.getUserCount().elementAt(i))){
					BingoHandler data = (BingoHandler)server.getUserCount().elementAt(i);
					data.pw.println(message);
					data.pw.flush();
				}
			}
		}
	}
}