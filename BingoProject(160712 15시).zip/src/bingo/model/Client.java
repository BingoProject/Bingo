package bingo.model;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
import bingo.view.*;

public class Client extends JFrame implements /*ActionListener,*/Runnable{
	private JPanel cardPane, connectPane, chatPane;
	private JLabel  msg;
	private JButton btn_connect, btn_send, btn_exit;
	private JTextField txt_server_ip, txt_name, txt_input;
	private TextArea txt_list;
	private CardLayout card;

	private String ip_txt;                  //ip를 기억할변수
	private Socket client;                  //소켓변수
	private final int port=8000;
	private PrintWriter pw;                 //출력버퍼
	private BufferedReader br;            //입력버퍼
	private MainFrame mainFrame;	
	private LoginDialog login;

	public Client()
	{
		
	}

	//=========Runnable 인터페이스의 run()메소드====================
	public void run() {
		try{
			client = new Socket("127.0.0.1", port);    //접속시도
			
			login = new LoginDialog();
			login.setModal(true);
			login.setLocation(550, 300);
			login.setSize(500, 200);
			login.setVisible(true);

			/*mainFrame = new MainFrame();
			mainFrame.makeFrame();*/
			
			//전송------------------------------------------
			String userId = login.getTextId().getText();
			//String userPwd = new String(login.getTextPwd().getPassword());
			//System.out.println(userId + ", " + userPwd);
			OutputStream os = client.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
			pw.println(userId);          //pw.print()   ----- X
			pw.flush();                      //전송
			
			mainFrame = new MainFrame(client);
			mainFrame.makeFrame();
			
			/*pw.println(userPwd);          //pw.print()   ----- X
			pw.flush();                      //전송
*/			//수신------------------------------------------
			/*InputStream is = client.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));
			String msg;
			while(true)
			{
				msg = br.readLine();
				txt_list.append(msg+"\n");
			}*/
		}catch(Exception e){}
	}

		
		/*super("Chatting Client(ver 1.0)");
		
		ConnectPane();
		ChatPane();
		
		//card-----------------------------
		cardPane = new JPanel();
		card = new CardLayout();
		cardPane.setLayout(card);
		cardPane.add(connectPane,"접속창");
		cardPane.add(chatPane,"채팅창");
		card.show(cardPane, "접속창");
		//----------------------------------
		add(cardPane);
		setSize(400,300);
		setVisible(true);
		addWindowListener(
			new WindowAdapter(){
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			}
		);
		//이벤트처리-----------------------
		btn_connect.addActionListener(this);
		btn_exit.addActionListener(this);
		btn_send.addActionListener(this);
		txt_input.addActionListener(this);
		//----------------------------------
	}
	public void ConnectPane()
	{
		connectPane = new JPanel();
		JPanel pn=new JPanel();
		JPanel pn1 = new JPanel();
		JPanel pn2 = new JPanel();
		
		msg = new JLabel("IP와 대화명을 입력하시오");
		msg.setFont(new Font("굴림체", Font.BOLD, 15));
		msg.setForeground(Color.magenta);
		
		JLabel lb1 = new JLabel("서버 I P : ");
		txt_server_ip = new JTextField("localhost", 15);
		pn1.add(lb1);    pn1.add(txt_server_ip);
		
		JLabel lb2 = new JLabel("대 화 명 : ");
		txt_name = new JTextField("캔디",15);		
		pn2.add(lb2);    pn2.add(txt_name);
		
		pn.add(pn1);     pn.add(pn2);    pn.add(msg);
		
		btn_connect = new JButton("Connection");
		
		connectPane.setBorder(BorderFactory.createTitledBorder("다중채팅화면"));
		connectPane.setLayout(new BorderLayout());
		connectPane.add(pn,"Center");
		connectPane.add(btn_connect,"South");
	}
	public void ChatPane()
	{
		chatPane = new JPanel();
		JPanel  pn = new JPanel();
		txt_list = new TextArea();
		txt_input = new JTextField("",20);
		btn_send = new JButton("전송");
		btn_exit = new JButton("종료");

		pn.setBorder(BorderFactory.createTitledBorder("☆대화하기☆"));
		chatPane.setBorder(BorderFactory.createTitledBorder("♣채팅내용♣"));
		pn.add(txt_input);   pn.add(btn_send);  pn.add(btn_exit);
		
		chatPane.setLayout(new BorderLayout());
		chatPane.add(txt_list, "Center");
		chatPane.add(pn, "South");
	}

	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		if(ob == btn_connect)
		{
			card.show(cardPane, "채팅창");
			ip_txt = txt_server_ip.getText();
			Thread th = new Thread(this);     //Runnable를 상속
			th.start();
		}
		if(ob ==btn_exit)
			System.exit(0);
		
		if(ob == btn_send || ob == txt_input)
		{
			String text = txt_input.getText();
			pw.println(text);
			pw.flush();
			txt_input.setText("");
			txt_input.requestFocus();
		}
	}*/
		
	/*//=========Runnable 인터페이스의 run()메소드====================
	public void run() {
		try{
			client = new Socket(ip_txt, port);    //접속시도
			//전송------------------------------------------
			String nickname = txt_name.getText();
			OutputStream os = client.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
			pw.println(nickname);          //pw.print()   ----- X
			pw.flush();                      //전송
			//수신------------------------------------------
			InputStream is = client.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));
			String msg;
			while(true)
			{
				msg = br.readLine();
				txt_list.append(msg+"\n");
			}
		}catch(Exception e){}
	}*/
	
	public static void main(String[] args) {
		new Client().run();
	}
	
}