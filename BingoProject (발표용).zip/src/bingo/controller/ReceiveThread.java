package bingo.controller;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import bingo.view.MainFrame;


public class ReceiveThread extends Thread{
	private MainFrame mainFrame;
	private Socket socket;
	private String receivedBtn;
	private BufferedReader br;            //입력버퍼
	private JButton[][] btnArr, btnArr2;
	private JButton randomBtn, readyBtn;
	private JLabel bingoCountLabel;
	private boolean[][] bool;
	private int myBingoCount;
	private int yourBingoCount;
	private boolean turn = false;
	private JPanel bingoPane;
	
	public int getBingoCount() {
		return myBingoCount;
	}

	public ReceiveThread(MainFrame mainFrame, Socket socket, JButton[][] btnArr, JButton[][] btnArr2, boolean[][] bool, JLabel bingoCountLabel, JPanel bingoPane, int yourBingoCount, JButton randomBtn, JButton readyBtn){
		this.mainFrame = mainFrame;
		this.socket = socket;
		this.btnArr = btnArr;
		this.btnArr2 = btnArr2;
		this.bool = bool;
		this.bingoCountLabel = bingoCountLabel;
		this.yourBingoCount = yourBingoCount;
		this.bingoPane = bingoPane;
		this.randomBtn = randomBtn;
		this.readyBtn = readyBtn;
		InputStream is;
		try {
			is = this.socket.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));       //입력스트림
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run(){
		while(true){
			try{
				receivedBtn = br.readLine();
				System.out.println(receivedBtn);
			}catch(IOException ee) {
				System.out.println("서버와 연결이 끊어졌습니다.");
				System.exit(1);
			}
			if(receivedBtn.equals("1명")){
				JOptionPane.showMessageDialog(mainFrame, "상대방을 기다려주세요");
				randomBtn.setEnabled(false);
			}else{
				randomBtn.setEnabled(true);
				break;
			}
		}
		
		while(true) {

			try{
				receivedBtn = br.readLine();
				System.out.println(receivedBtn);
			}catch(IOException ee) {
				System.out.println("서버와 연결이 끊어졌습니다.");
				System.exit(1);
				
			}
			
			switch(receivedBtn){
			case "선공" :
				
				JOptionPane.showMessageDialog(bingoPane, "선공입니다");
				mainFrame.setTurn(true);
				break;
			case "후공" :
				
				JOptionPane.showMessageDialog(bingoPane, "후공입니다");
				mainFrame.setTurn(false);
				break;
			}
			
			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < 5; j++){
					
					if(receivedBtn.equals(btnArr[i][j].getText())){
						btnArr[i][j].setBackground(Color.pink);
						btnArr[i][j].setEnabled(false);
						bool[i][j] = true;
						BingoCheck bc = new BingoCheck(bool, bingoCountLabel, btnArr);
						myBingoCount = bc.bingoCount();
						System.out.println("빙고 카운트 : " + myBingoCount);
						if(myBingoCount >= 5){
							SendThread st = new SendThread(mainFrame, socket, "승리", myBingoCount, turn);
							st.start();
							mainFrame.getBingoPane2().setVisible(true);
							JOptionPane.showConfirmDialog(mainFrame, "승리하셨습니다. 다시하시겠습니까?");
						}
					}
					if(receivedBtn.equals(btnArr2[i][j].getText())){
						btnArr2[i][j].setBackground(Color.RED);
						btnArr2[i][j].setEnabled(false);
						bool[i][j] = true;
						BingoCheck bc = new BingoCheck(bool,/* myBingoCount, */bingoCountLabel, btnArr);
						myBingoCount = bc.bingoCount();
						System.out.println("빙고 카운트 : " + myBingoCount);
					}else if(receivedBtn.equals(myBingoCount + "빙고")){
						btnArr2[i][j].setEnabled(false);
					}
				}
			}
			if(receivedBtn.equals("턴 종료")){
				for(int i = 0; i < 5; i++) {
					for(int j = 0; j < 5; j++){
						if(!(btnArr[i][j].getBackground().equals(Color.pink) || 
								btnArr[i][j].getBackground().equals(Color.RED)))
						btnArr[i][j].setEnabled(true);
					}
				}
			}
			if(receivedBtn.equals("승리!!")){
				for(int i = 0; i < 5; i++) {
					for(int j = 0; j < 5; j++){
						btnArr[i][j].setEnabled(false);
					}
				}
				mainFrame.getBingoPane2().setVisible(true);
				JOptionPane.showMessageDialog(mainFrame, "패배하셨습니다. 프로그램을 종료합니다.");
				System.exit(0);
				/*int result = JOptionPane.showConfirmDialog(mainFrame, "패배하셨습니다. 다시하시겠습니까?", "패배", JOptionPane.YES_NO_OPTION);
				if(result == 0){
					for(int i = 0 ; i< btnArr.length; i++){
						for(int j = 0 ; j < btnArr[i].length; j++){
							btnArr[i][j].setText("");
							btnArr[i][j].setBackground(new Color(238,238,238));
							btnArr[i][j].setEnabled(false);
							randomBtn.setEnabled(true);
						}
					}
				}else{
					System.exit(0);
				}*/
				
				
			}
			for(int i = 0 ; i < 5; i ++){
				if(receivedBtn.equals(String.valueOf(i)+"빙고")){
					yourBingoCount = i;
				}
				
			}
			
			if(receivedBtn.equals("상대방이 나가 게임을 종료합니다.")){
				JOptionPane.showConfirmDialog(mainFrame, "상대방이 나가 게임을 종료합니다. 다시 하시겠습니까?");
			}
			
			if(receivedBtn.equals("준비완료")){
				if(mainFrame.isReady() == true){
					JOptionPane.showMessageDialog(mainFrame, "상대방의 준비가 완료되었습니다. 게임을 시작합니다");
					SendThread st = new SendThread(mainFrame, socket, "시작", myBingoCount, turn);
					st.start();
					if(turn == true){
						for(int i = 0; i < btnArr.length; i++){
							for(int j = 0; j < btnArr[i].length; j++)
								btnArr[i][j].setEnabled(true);
						}
					}else{
						for(int i = 0; i < btnArr.length; i++){
							for(int j = 0; j < btnArr[i].length; j++)
								btnArr[i][j].setEnabled(false);
						}
					}
					
					if(mainFrame.isTurn() == true){
						for(int i = 0; i < mainFrame.getBtnArr().length; i++){
							for(int j = 0; j < mainFrame.getBtnArr()[i].length; j++)
								mainFrame.getBtnArr()[i][j].setEnabled(true);
						}
					}else{
						for(int i = 0; i < mainFrame.getBtnArr().length; i++){
							for(int j = 0; j < mainFrame.getBtnArr()[i].length; j++)
								mainFrame.getBtnArr()[i][j].setEnabled(false);
						}
					}
					
				}else if(mainFrame.isReady() == false){
					JOptionPane.showMessageDialog(mainFrame, "상대방의 준비가 완료되었습니다. 준비를 서둘러주세요");
				}
					
			}
			if(receivedBtn.equals("시작")){
				System.out.println("turn = " + turn);
				if(mainFrame.isTurn() == true){
					for(int i = 0; i < mainFrame.getBtnArr().length; i++){
						for(int j = 0; j < mainFrame.getBtnArr()[i].length; j++)
							mainFrame.getBtnArr()[i][j].setEnabled(true);
					}
				}else{
					for(int i = 0; i < mainFrame.getBtnArr().length; i++){
						for(int j = 0; j < mainFrame.getBtnArr()[i].length; j++)
							mainFrame.getBtnArr()[i][j].setEnabled(false);
					}
				}
			}
			if(receivedBtn.equals("버튼전달")){
				for(int i = 0 ; i < btnArr2.length; i++){
					for(int j = 0 ; j < btnArr2[i].length; j++){
						btnArr2[i][j].setText(receivedBtn); 
					}
				}
			}
		}		
	}

}
