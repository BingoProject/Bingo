package bingo.model;

import javax.swing.*;

public class BingoCheck /*extends Thread*/ {
	private boolean[][] bool;
	private JButton[][] btnArr;
	private int bingoCount;
	
	public int getBingoCount() {
		return bingoCount;
	}

	JLabel bingoCountLabel;

	public BingoCheck(boolean[][] bool, /*int bingoCount,*/ JLabel bingoCountLabel, JButton[][] btnArr) {
		this.bool = bool;
		this.bingoCount = bingoCount;
		this.bingoCountLabel = bingoCountLabel;
		this.btnArr = btnArr;
	}
	
	public int bingoCount() {
		//bingoCount = 0;
		System.out.println("BingoThread run 시작부분");
		for(int i = 0; i < 5; i++) {
			if(bool[i][0] && bool[i][1] && bool[i][2] && bool[i][3] && bool[i][4]) {
				bingoCount++;
			}

			if(bool[0][i] && bool[1][i] && bool[2][i] && bool[3][i] && bool[4][i]) {
				bingoCount++;
			}
		}
		
		if(bool[0][0] && bool[1][1] && bool[2][2] && bool[3][3] && bool[4][4]) {
			bingoCount++;
		}

		if(bool[4][0] && bool[3][1] && bool[2][2] && bool[1][3] && bool[0][4]) {
			bingoCount++;
		}
		if(bingoCount < 5) {
			System.out.println("BingoCheck Thread안의 bingoCount값 : " + bingoCount);
			bingoCountLabel.setText("현재 " + bingoCount + "빙고");
			
		}
		else {
			bingoCountLabel.setText( bingoCount + "빙고! 승리하셨습니다.");
			for(int i = 0 ; i < btnArr.length; i++){
				for(int j = 0 ; j < btnArr[i].length; j++){
					btnArr[i][j].setEnabled(false);
				}
			}
		}
		System.out.println("BingoThread run 종료부분");
		return bingoCount;
	}
	
/*	public void run() {
		//bingoCount = 0;
		System.out.println("BingoThread run 시작부분");
		for(int i = 0; i < 5; i++) {
			if(bool[i][0] && bool[i][1] && bool[i][2] && bool[i][3] && bool[i][4]) {
				bingoCount++;
			}

			if(bool[0][i] && bool[1][i] && bool[2][i] && bool[3][i] && bool[4][i]) {
				bingoCount++;
			}
		}
		
		if(bool[0][0] && bool[1][1] && bool[2][2] && bool[3][3] && bool[4][4]) {
			bingoCount++;
		}

		if(bool[4][0] && bool[3][1] && bool[2][2] && bool[1][3] && bool[0][4]) {
			bingoCount++;
		}
		if(bingoCount < 5) {
			System.out.println("BingoCheck Thread안의 bingoCount값 : " + bingoCountgetBingoCount());
			bingoCountLabel.setText("현재 " + bingoCountgetBingoCount() + "빙고");
			
		}
		else {
			bingoCountLabel.setText( bingoCountgetBingoCount() + "빙고! 승리하셨습니다.");
			for(int i = 0 ; i < btnArr.length; i++){
				for(int j = 0 ; j < btnArr[i].length; j++){
					btnArr[i][j].setEnabled(false);
				}
			}
		}
		System.out.println("BingoThread run 종료부분");
	}*/
}
