package bingo.controller;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JButton;


public class ReceiveThread extends Thread{
	private Socket socket;
	private String receivedBtn;
	private BufferedReader br;            //입력버퍼
	private JButton[] btnArr;
	
	
	public ReceiveThread(Socket socket, JButton[] btnArr){
		this.socket = socket;
		this.btnArr = btnArr;
		
		InputStream is;
		try {
			is = this.socket.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));       //입력스트림
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run(){
		while(true) {

			try{
				receivedBtn = br.readLine();
			}catch(IOException ee) {
				//ee.printStackTrace();
				System.out.println("서버가 종료되었습니다.");
				System.exit(1);
				
			}		

			for(int i = 0; i < 25; i++) {
				if(receivedBtn.equals(btnArr[i].getText())){
					btnArr[i].setBackground(Color.RED);
					btnArr[i].setEnabled(false);
				}
			}
		}		
	}

}
