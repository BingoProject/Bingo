package bingo.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

class BingoHandler extends Thread
{
	Server server;
	Socket sock;
	BufferedReader br;
	PrintWriter pw;

	public BingoHandler(Server server, Socket sock)
	{
		this.server = server;
		this.sock = sock;
		try{
			InputStream is = sock.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));       //입력스트림

			OutputStream os = sock.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));          //출력스트림
			
			
		}catch(Exception e){}
	}
	//--------------------------------------------------------------
	public void run()
	{
		String nickname=null;
		try{
			nickname = br.readLine();    
			server.setMsg("[" + nickname +"]님이 입장하셨습니다");
			sendAll("[" + nickname +"]님이 입장하셨습니다");
			if(server.userCount.size() == 1){
				System.out.println(String.valueOf(server.userCount.size())+"명");
				pw.println(String.valueOf(server.userCount.size())+"명");
				pw.flush();
			}
			else{
				pw.println(String.valueOf(server.userCount.size())+"명");
				pw.flush();
				sendAll(String.valueOf(server.userCount.size())+"명");
			}
			sendTurn();
			while(true)  //대화중시작
			{
				String text = br.readLine();
				server.setMsg(nickname + " : " + text + "선택");
				sendAll(/*nickname + ">>" + */text);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			synchronized(server.userCount){           //동기화처리(부하방지)

				server.setMsg("[" + nickname +"]님이 퇴장하셨습니다");
				sendAll("[" + nickname +"]님이 퇴장하셨습니다");
				server.userCount.removeElement(this);
				if(server.userCount.size() < 2)
					sendAll("상대방이 나가 게임을 종료합니다.");
			}
		}
	}
	public void sendTurn() {
		synchronized(server.userCount){
			int s = server.userCount.size();        //인원수체크
			if(s > 1){
				for(int i=0; i<s; i++)
				{
					if(i==0 /*&& this.equals(server.userCount.elementAt(i))*/){
						BingoHandler data = (BingoHandler)server.userCount.elementAt(i);
						data.pw.println("선공");
						data.pw.flush();
					}else if(this.equals(server.userCount.elementAt(i))){
						BingoHandler data = (BingoHandler)server.userCount.elementAt(i);
						data.pw.println("후공");
						data.pw.flush();
					}
				}
			}
		}
	}
	//모든접속자에게 메세지를 보냄-----------------------------------------
	public void sendAll(String msg)
	{
		synchronized(server.userCount){
			int s = server.userCount.size();        //인원수체크

			for(int i=0; i<s; i++)
			{
				if(!this.equals(server.userCount.elementAt(i))){
					BingoHandler data = (BingoHandler)server.userCount.elementAt(i);
					data.pw.println(msg);
					data.pw.flush();
				}
			}
		}
	}
}