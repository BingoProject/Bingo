package bingo.controller;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JLabel;

import bingo.model.BingoCheck;


public class ReceiveThread extends Thread{
	private Socket socket;
	private String receivedBtn;
	private BufferedReader br;            //입력버퍼
	private JButton[][] btnArr;
	private JLabel bingoCountLabel;
	private boolean[][] bool;
	private int bingoCount;
	
	public ReceiveThread(Socket socket, JButton[][] btnArr, boolean[][] bool, JLabel bingoCountLabel, int bingoCount){
		this.socket = socket;
		this.btnArr = btnArr;
		this.bool = bool;
		this.bingoCountLabel = bingoCountLabel;
		this.bingoCount = bingoCount;
		InputStream is;
		try {
			is = this.socket.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));       //입력스트림
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run(){
		while(true) {

			try{
				receivedBtn = br.readLine();
			}catch(IOException ee) {
				//ee.printStackTrace();
				System.out.println("서버가 종료되었습니다.");
				System.exit(1);
				
			}		

			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < 5; j++)
				if(receivedBtn.equals(btnArr[i][j].getText())){
					btnArr[i][j].setBackground(Color.RED);
					btnArr[i][j].setEnabled(false);
					bool[i][j] = true;
					BingoCheck bc = new BingoCheck(bool, bingoCount, bingoCountLabel, btnArr);
					bc.start();
				}
			}
		}		
	}

}
