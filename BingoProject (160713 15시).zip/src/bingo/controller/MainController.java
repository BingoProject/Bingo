package bingo.controller;

import java.util.*;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

import bingo.model.User;
import bingo.model.UserInfo;

public class MainController {
	
	private HashMap<String, User> users;
	
	public MainController(){
		//this.users = users;
		UserInfo user = new UserInfo();
		users = user.readProperties();
		
		/*User[] userList = new User[]{
				new User("user01", "pass01", "smileman"),
				new User("user02", "pass02", "prittywoman"),
				new User("user03", "pass03", "javajjang"),
				new User("test123", "test123", "testboy"),
				new User("p1234", "p1234", "pick")};
		
		for(User u : userList)
			users.put(u.getUserId(), u);*/
		
	}

	public int loginCheck(String id, String pwd) {
		int result = -1;
		if(users.containsKey(id)){
			System.out.println(users.get(id));
			User loginUser = users.get(id);
			if(loginUser.getUserPwd().equals(pwd)){
				result = 1;
			}
		}
		return result;
	}

	public void insertUser(User user) {
		
		users.put(user.getUserId(), user);
		System.out.println(user.getUserId() + " 등록 완료!");
	}
	
	
}
