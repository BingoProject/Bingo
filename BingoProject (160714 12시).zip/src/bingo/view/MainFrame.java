package bingo.view;

import java.awt.*;
import java.awt.event.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.*;

import bingo.controller.ReceiveThread;
import bingo.controller.SendThread;
import bingo.model.BingoCheck;

public class MainFrame extends JFrame implements ActionListener{
	private JButton[][] btnArr = new JButton[5][5];
	private JButton[][] btnArr2 = new JButton[5][5];
	private JButton randomBtn, readyBtn;
	private JLabel bingoCountLabel;
	private JPanel bingoPane, bingoPane2, readyPane, bingoCountPane /*, memberPane*/;
	private String selectBtn;
	private Socket socket;
//	private int bingoCount;
	private int myBingoCount;
	private int yourBingoCount;
	private boolean[][] bool = new boolean[5][5];
	private boolean turn = false;
	
	////////////////////////////////////////////////
	public int getMyBingoCount() {
		return myBingoCount;
	}


	public void setMyBingoCount(int myBingoCount) {
		this.myBingoCount = myBingoCount;
	}


	public int getYourBingoCount() {
		return yourBingoCount;
	}


	public void setYourBingoCount(int yourBingoCount) {
		this.yourBingoCount = yourBingoCount;
	}
////////////////////////////////////////////////////////

	public boolean isTurn() {
		return turn;
	}


	public void setTurn(boolean turn) {
		this.turn = turn;
	}


/*	public int getBingoCount() {
		return bingoCount;
	}


	public void setBingoCount(int bingoCount) {
		this.bingoCount = bingoCount;
	}*/


	public MainFrame(Socket socket){
		this.socket = socket;
		//빙고카운트용 boolean변수 초기화
		for(int i = 0 ; i < bool.length; i++){
			for(int j = 0 ; j < bool[i].length; j++){
				bool[i][j] = false;
			}
		}
	}
	
	
	public void makeFrame(){

		//메인프레임 set하기
		this.setTitle("빙고 게임");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(300, 100, 1050, 650);
		this.setLayout(null);
		

		//빙고 판 set하기
		//내 빙고판
		bingoPane = new JPanel();
		bingoPane.setBackground(Color.lightGray);
		bingoPane.setLocation(0, 0);
		bingoPane.setLayout(new GridLayout(5, 5));
		bingoPane.setSize(500, 500);
		
		//상대편 빙고판
		bingoPane2 = new JPanel();
		bingoPane2.setBackground(Color.lightGray);
		bingoPane2.setLocation(532, 0);
		bingoPane2.setLayout(new GridLayout(5, 5));
		bingoPane2.setSize(500, 500);
		
		for(int i = 0; i < btnArr.length; i++){
			for(int j = 0 ; j < btnArr[i].length; j++){
				btnArr[i][j] = new JButton("버튼");
				btnArr2[i][j] = new JButton();
				btnArr[i][j].setEnabled(false);
				btnArr[i][j].addActionListener(this);
				
				bingoPane.add(btnArr[i][j]);
				bingoPane2.add(btnArr2[i][j]);
			}
			
		}
		this.add(bingoPane2);
		this.add(bingoPane);
		
		bingoPane.setEnabled(false);
		bingoPane.setVisible(true);
		bingoPane2.setVisible(false);

		//빙고 갯수 표시 패널
		bingoCountPane = new JPanel();
		bingoCountLabel = new JLabel("0 빙고 ");
		bingoCountLabel.setFont(new Font(bingoCountLabel.getText(), Font.BOLD, 35));


		bingoCountPane.setBackground(Color.lightGray);
		bingoCountPane.setSize(1035, 50);
		bingoCountPane.setLocation(0, 560);


		bingoCountPane.add(bingoCountLabel);
		this.add(bingoCountPane);
		
		
		//자동 채우기 버튼 & 준비 버튼 
		readyBtn = new JButton("준비 완료");
		readyBtn.setFont(new Font(readyBtn.getText(), Font.BOLD, 30));
		readyBtn.setBackground(Color.lightGray);
		readyBtn.setEnabled(false);
		
		readyPane = new JPanel();
		readyPane.setLayout(new GridLayout(1, 2));
		readyPane.setSize(1035, 60);
		readyPane.setLocation(0, 500);
		
		
		randomBtn = new JButton("자동 채우기");
		randomBtn.setFont(new Font(randomBtn.getText(), Font.BOLD, 30));
		randomBtn.setBackground(Color.lightGray);
		
		readyPane.add(randomBtn);
		readyPane.add(readyBtn);
		
		randomBtn.addActionListener(this);
		readyBtn.addActionListener(this);
		
		this.add(readyPane, BorderLayout.SOUTH);
		/*this.add(readyBtn, BorderLayout.SOUTH);
		this.add(randomBtn, BorderLayout.SOUTH);*/
		
		readyPane.setVisible(true);
		randomBtn.setVisible(true);
		/*//회원 관리 set하기
		memberPane = new JPanel();
		memberPane.setLayout(new BoxLayout(memberPane, BoxLayout.Y_AXIS));
		memberPane.setSize(100, 100);
		memberPane.setLocation(950, 100);
		
		memberPane.add(new JLabel("ID : ", Label.LEFT));
		memberPane.add(new JTextField(15));
		memberPane.add(new JLabel("PWD : ", Label.LEFT));
		memberPane.add(new JTextField(15));
		
		this.add(memberPane, BorderLayout.EAST);
		memberPane.setVisible(true);*/
		
		

		ReceiveThread rt = new ReceiveThread(this, socket, btnArr, btnArr2, bool, bingoCountLabel, yourBingoCount, bingoPane);
		rt.start();
		//setBingoCount(rt.getBingoCount());
		this.setVisible(true);
		
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		// 자동 채우기 버튼
		boolean duplicated = false;
		if(e.getActionCommand().equals(randomBtn.getText())){
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					int random = (int)(Math.random() * 50) + 1;
					btnArr[i][j].setText(String.valueOf(random));
					btnArr[i][j].setFont(new Font(btnArr[i][j].getText(), Font.BOLD, 25));
					
					for(int k = 0 ; k <= i ; k++){
						if( k == i ){
							for(int l = 0; l < j ;l++){
								//System.out.println(btnArr[k][l].getText() + ", " + String.valueOf(random));
								if(btnArr[k][l].getText().equals(String.valueOf(random))){
									duplicated = true;
									break;
								}
							}
						}else{
							for(int l = 0 ; l < 5; l++){
								//System.out.println(btnArr[k][l].getText() + ", " + String.valueOf(random));
								if(btnArr[k][l].getText().equals(String.valueOf(random))){
									duplicated = true;
									break;
								}
							}
						}
						if(duplicated == true){
							j--;
							duplicated = false;
							break;
						}
					}
					
				}
			}
			readyBtn.setEnabled(true);
			
		}
		
		// 준비 완료 버튼
		else if(e.getActionCommand().equals(readyBtn.getText())){
			if(turn == true){
				for(int i = 0; i < btnArr.length; i++){
					for(int j = 0; j < btnArr[i].length; j++)
						btnArr[i][j].setEnabled(true);
				}
			}else{
				for(int i = 0; i < btnArr.length; i++){
					for(int j = 0; j < btnArr[i].length; j++)
						btnArr[i][j].setEnabled(false);
				}
			}
			
			randomBtn.setEnabled(false);
			readyBtn.setEnabled(false);
		}
		
		// 빙고 버튼
		else{
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					if(e.getActionCommand().equals(btnArr[i][j].getText())){
						btnArr[i][j].setBackground(Color.RED);
						btnArr[i][j].setEnabled(false);
						selectBtn = btnArr[i][j].getText();
						bool[i][j] = true;
						
						/*BingoCheck bc = new BingoCheck(bool, bingoCount, bingoCountLabel, btnArr);
						bc.start();
						System.out.println("BingoCheck start후");
						System.out.println("BingoCheck의 bingoCount 값 : " + bc.getBingoCount());
						setBingoCount(bc.getBingoCount());*/
						BingoCheck bc = new BingoCheck(bool, myBingoCount, bingoCountLabel, btnArr);
						//bc.start();
						myBingoCount = bc.bingoCount();
						SendThread st = new SendThread(this, socket, selectBtn, myBingoCount, turn);
						st.start();
						System.out.println("SendThread start후");
						if(myBingoCount >= 5){
							bingoPane2.setVisible(true);
							JOptionPane.showConfirmDialog(this, "승리하셨습니다. 다시하시겠습니까?");
						}
						else if(yourBingoCount >= 5){
							bingoPane2.setVisible(true);
							JOptionPane.showConfirmDialog(this, "패배하셨습니다. 다시하시겠습니까?");
						}
						
						/*SendThread st = new SendThread(socket, selectBtn, bingoCount);
						st.start();
						System.out.println("SendThread start후");
						BingoCheck bc = new BingoCheck(bool, bingoCount, bingoCountLabel, btnArr);
						bc.start();
						System.out.println("BingoCheck start후");
						setBingoCount(bc.getBingoCount());*/
						
						
						/*System.out.println("현재 빙고카운트" + bingoCount);
						if(bingoCount >= 5){
							bingoPane2.setVisible(true);
							JOptionPane.showConfirmDialog(this, "다시하시겠습니까?");
						}
						System.out.println("==============================");*/
					}
				}
			}
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					btnArr[i][j].setEnabled(false);
				}
			}
		}
	}
	
}


/*package bingo.view;

import java.awt.*;
import java.awt.event.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.*;

import bingo.controller.SendThread;

public class MainFrame extends JFrame implements ActionListener{
	private JButton[] btnArr = new JButton[25];
	private JButton randomBtn, readyBtn;
	private JPanel bingoPane, readyPane; memberPane;
	private String selectBtn;
	private Socket socket;
	
	public MainFrame(Socket socket){
		this.socket = socket;
	}
	
	public void makeFrame(){

		//메인프레임 set하기
		this.setTitle("빙고 게임");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200, 100, 1000, 600);
		this.setLayout(new BorderLayout());
		
		
		//빙고 판 set하기
		bingoPane = new JPanel();
		bingoPane.setBackground(Color.lightGray);
		bingoPane.setSize(1000, 500);
		bingoPane.setLocation(20, 20);
		bingoPane.setLayout(new GridLayout(5, 5));
		
		for(int i = 0; i < btnArr.length; i++){
			
			btnArr[i] = new JButton("버튼");
			
			btnArr[i].addActionListener(this);
			bingoPane.add(btnArr[i]);
		}
		this.add(bingoPane, BorderLayout.CENTER);
		bingoPane.setVisible(true);
		
		//자동 채우기 버튼
		randomBtn = new JButton("자동 채우기");
		randomBtn.setBackground(Color.lightGray);
//		randomBtn.setSize(500, 200);
		
		readyPane = new JPanel();
		readyBtn = new JButton("준비완료");
		readyBtn.addActionListener(this);
//		readyBtn.setSize(500,200);
		readyPane.add(randomBtn);
		readyPane.add(readyBtn);
		readyPane.setLayout(new GridLayout(1,2));
		this.add(readyPane, BorderLayout.SOUTH);
		randomBtn.addActionListener(this);
		randomBtn.setVisible(true);
		
		//회원 관리 set하기
		memberPane = new JPanel();
		memberPane.setLayout(new BoxLayout(memberPane, BoxLayout.Y_AXIS));
		memberPane.setSize(100, 100);
		memberPane.setLocation(950, 100);
		
		memberPane.add(new JLabel("ID : ", Label.LEFT));
		memberPane.add(new JTextField(15));
		memberPane.add(new JLabel("PWD : ", Label.LEFT));
		memberPane.add(new JTextField(15));
		
		this.add(memberPane, BorderLayout.EAST);
		memberPane.setVisible(true);
		
		
		
		
		
		this.setVisible(true);
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// 자동 채우기 버튼
		if(e.getActionCommand().equals(randomBtn.getText())){
			for(int i = 0; i < btnArr.length; i++){
				int rNum = (int)(Math.random() * 50) + 1;
				btnArr[i].setText(String.valueOf(rNum));
				btnArr[i].setFont(new Font(btnArr[i].getText(), Font.BOLD, 30));
				//System.out.println(btnArr[i].getText());
				for(int j = 0 ; j < i ; j++){
					if( String.valueOf(rNum).equals(btnArr[j].getText())){
						i--;
						break;
					}
				}
				btnArr[i].setEnabled(false);
			}
		randomBtn.setEnabled(false);
		}
		
		// 준비 완료 버튼
		else if(e.getActionCommand().equals(readyBtn.getText())){
			for(int i = 0; i < btnArr.length; i++){
				btnArr[i].setEnabled(true);
			}
			readyBtn.setEnabled(false);
		}
		
		// 빙고 버튼
		else{
			for(int i = 0; i < btnArr.length; i++){
				if(e.getActionCommand().equals(btnArr[i].getText())){
					btnArr[i].setBackground(Color.RED);
					btnArr[i].setEnabled(false);
					selectBtn = btnArr[i].getText();
					SendThread st = new SendThread(socket, selectBtn);
					st.start();
					
					break;
				}
			}
		}
	}
	
}
*/