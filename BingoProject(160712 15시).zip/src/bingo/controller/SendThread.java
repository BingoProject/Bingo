package bingo.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.*;

public class SendThread extends Thread{
	private Socket socket;
	private String selectBtn;
	private PrintWriter pw;                 //출력버퍼
	
	public SendThread(Socket socket, String selectBtn)
	{
		this.socket = socket;
		this.selectBtn = selectBtn;
		
		OutputStream os;
		try {
			os = this.socket.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void run(){
		pw.println(selectBtn);
		pw.flush();
	}
}
