package bingo.run;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
import bingo.view.*;

public class Client extends JFrame implements Runnable{

	private String ip;				//ip를 기억할변수
	private Socket client;			//소켓변수
	private final int port=8000;	//포트번호
	private PrintWriter pw;			//출력버퍼
	private BufferedReader br;		//입력버퍼
	private MainFrame mainFrame;	//참조할 MainFrame 인스턴스
	private LoginDialog login;		//참조할 LoginDialog 인스턴스

	public Client()
	{
		
	}

	//Runnable 인터페이스의 run()메소드
	public void run() {
		try{
			ip = "127.0.0.1";
			client = new Socket(ip, port);    //접속시도
			
			//loginDialog 객체 생성하여 로그인에 관한 처리를 함
			login = new LoginDialog();
			login.setModal(true);
			login.setLocation(550, 300);
			login.setSize(500, 200);
			login.setVisible(true);
			
			// 로그인 완료시 id를 서버에 전달
			String userId = login.getTextId().getText();
			OutputStream os = client.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
			pw.println(userId);          
			pw.flush();                

			//MainFrame 객체 생성하여 실행
			mainFrame = new MainFrame(client);
			mainFrame.makeFrame();

		}catch(Exception e){}
	}
	
	public static void main(String[] args) {
		new Client().run();
	}
	
}
