package bingo.run;

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import bingo.controller.BingoHandler;

import java.io.*;
import java.net.*;

public class Server extends JFrame implements ActionListener{
	//Field
	private TextArea txtArea;	// 클라이언트간에 송수신되는 텍스트 출력 공간
	private JButton exitBtn;	// 종료 버튼
	private Vector userCount;	// 접속한 유저 숫자 카운트

	//Constructor
	public Server(){
		super("Bingo Server");

		txtArea = new TextArea();
		exitBtn = new JButton("서버종료");

		add(txtArea, "Center");
		add(exitBtn,"South");
		setSize(500,500);
		setVisible(true);

		// 윈도우창 x 버튼 클릭시 프로그램 종료
		addWindowListener(
				new WindowAdapter(){
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				}
				);
		exitBtn.addActionListener(this);
		userCount = new Vector();
		ServerSocket();
	}

	//Method
	public void ServerSocket()
	{
		final int port=8000;
		try{
			ServerSocket ss = new ServerSocket(port);            //접속대기중
			while(true)
			{
				System.out.println("클라이언트 접속 대기중...");
				Socket client = ss.accept();                          	//요청수락
				String str = client.getInetAddress().getHostAddress();	//ip주소 받기
				System.out.println(client.getInetAddress().getHostAddress() + 
						"연결완료!");
				txtArea.append(str + "에서 접속!!");               

				//병행처리를 하기위한 Client객체를 생성(사용자정의클래스)-------
				BingoHandler ch = new BingoHandler(this,client);
				userCount.addElement(ch);           //객체추가(인원수)
				ch.start();

			}
		}catch(Exception e){
			System.out.println("클라이언트 종료");
		}
	}
	
	//Setters & Getters
	public void setMsg(String msg)  //txt_list에  nickname or 대화내용을 출력
	{
		txtArea.append(msg+"\n");
	}
	
	public void actionPerformed(ActionEvent e) {	//종료버튼 클릭시 프로그램 종료
		if(e.getSource() == exitBtn)
			System.exit(0);
	}	
	
	public TextArea getTxt_list() {
		return txtArea;
	}
	public void setTxt_list(TextArea txt_list) {
		this.txtArea = txt_list;
	}
	public JButton getBtn_exit() {
		return exitBtn;
	}
	public void setBtn_exit(JButton btn_exit) {
		this.exitBtn = btn_exit;
	}
	public Vector getUserCount() {
		return userCount;
	}
	public void setUserCount(Vector userCount) {
		this.userCount = userCount;
	}
	
}