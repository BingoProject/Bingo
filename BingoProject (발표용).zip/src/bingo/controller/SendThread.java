package bingo.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.*;

import javax.swing.JButton;

import bingo.view.MainFrame;

public class SendThread extends Thread{
	private MainFrame mainFrame;
	private Socket socket;
	private String selectBtn;
	private int myBingoCount = 0;
	private boolean turn;
	private PrintWriter pw;                 //출력버퍼
	private JButton[][] btnArr;
	
	public SendThread(Socket socket, String selectBtn)
	{
		this.socket = socket;
		this.selectBtn = selectBtn;
		
		OutputStream os;
		try {
			os = this.socket.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	 
	public SendThread(MainFrame mainFrame, Socket socket, String selectBtn, int myBingoCount, boolean turn)
	{
		this.mainFrame = mainFrame;
		this.socket = socket;
		this.selectBtn = selectBtn;
		this.myBingoCount = myBingoCount;
		this.turn = turn;
		
		OutputStream os;
		try {
			os = this.socket.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(os));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	 public SendThread(MainFrame mainFrame, Socket socket, String selectBtn, int myBingoCount, boolean turn, JButton[][] btnArr)
		{
			this.mainFrame = mainFrame;
			this.socket = socket;
			this.selectBtn = selectBtn;
			this.myBingoCount = myBingoCount;
			this.turn = turn;
			this.btnArr = btnArr;
			
			OutputStream os;
			try {
				os = this.socket.getOutputStream();
				pw = new PrintWriter(new OutputStreamWriter(os));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	 
	 
	public void run(){
		System.out.println("SendThread run 시작부분");
		if(selectBtn.equals("준비완료")){
			pw.println(selectBtn);
			pw.flush();
		}
		else if(selectBtn.equals("시작")){
			pw.println(selectBtn);
			pw.flush();
		}
		else if(myBingoCount/*bingoCount*/ >= 5){
			pw.println("승리!!");
			pw.flush();
			mainFrame.setTurn(false);
		}
		else if(selectBtn.equals("빙고전달")){
			pw.println("버튼전달");
			pw.flush();
			for(int i = 0 ; i < btnArr.length; i++){
				for(int j = 0 ; j < btnArr[i].length; j++){
					pw.println(btnArr[i][j]);
					pw.flush();
				}
			}
		}
		else{
			System.out.println("SendThread안의 bingoCount 값 : " + myBingoCount);
			pw.println(selectBtn);
			pw.flush();
			pw.println("턴 종료");
			pw.flush();
			pw.println(String.valueOf(myBingoCount)+"빙고");
			pw.flush();
			mainFrame.setTurn(false);
		}
		System.out.println("SendThread run 종료부분");
	}
}
