package bingo.model;

import java.io.*;
import java.util.*;

public class UserService {

	public UserService(){}
	
	//user.properties 파일 읽기
	public Map<String, User> readProperties(){
		Map<String, User> users= null;
		Properties prop = new Properties();
		try {
			prop.load(new FileReader("resource/user.properties"));
			
			if(prop.size() > 0){
				users = new HashMap<String, User>();
				Iterator entryIter = prop.entrySet().iterator();
				
				while(entryIter.hasNext()){
					Map.Entry entry = (Map.Entry)entryIter.next();
					String key = (String)entry.getKey();
					String value = (String)entry.getValue();
					String[] values = value.split(",");
					
					users.put(key, new User(values[0], values[1], values[2]));
				}
					//System.out.println(users);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return users;
	}
	
	//user.properties 에 기록 저장하기
	public boolean saveProperties(Map<String, User> users){
		boolean result = false;
		Properties prop = new Properties();
		
		Iterator<Map.Entry<String, User>> entryIter = users.entrySet().iterator();
		while(entryIter.hasNext()){
			Map.Entry<String, User> entry = entryIter.next();
			prop.setProperty(entry.getKey(), entry.getValue().toString());
		}
		
		try {
			prop.store(new FileWriter("resource/user.properties"/*, true*/), "User Info");
			result = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result; 
	}
	
	public static void main(String[] args){
		UserService uservice = new UserService();
		
		Map<String, User> users = uservice.readProperties();
		System.out.println(users);
		users.put("user05", new User("user05","pass05","이민수"));
		uservice.saveProperties(users);
		System.out.println(users);
	}
	

}
