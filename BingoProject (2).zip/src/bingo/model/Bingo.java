package bingo.model;

public class Bingo {

}
