package bingo.controller;

import java.util.*;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

import bingo.model.User;

public class MainController {
	
	private HashMap<String, User> users;
	
	public MainController(){
		//this.users = users;

		users = new HashMap<String, User>();
		
		User[] userList = new User[]{
				new User("user01", "pass01", "smileman"),
				new User("user02", "pass02", "prittywoman"),
				new User("user03", "pass03", "javajjang"),
				new User("test123", "test123", "testboy"),
				new User("p1234", "p1234", "pick")};
		
		for(User u : userList)
			users.put(u.getUserId(), u);
		
	}

	public int loginCheck(String id, String pwd) {
		int result = -1;
		if(users.containsKey(id)){
			System.out.println(users.get(id));
			User loginUser = users.get(id);
			if(loginUser.getUserPwd().equals(pwd)){
				result = 1;
			}
		}
		return result;
	}

	public void insertUser(String userId, String userPwd, String userName) {
		
		users.put(userId, new User(userId, userPwd, userName));
		System.out.println(userId + " 등록 완료!");
	}
	
	
}
