package bingo.view;

import java.awt.*;
import java.awt.event.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.*;

import bingo.controller.BingoCheck;
import bingo.controller.ReceiveThread;
import bingo.controller.SendThread;
import bingo.run.Server;

public class MainFrame extends JFrame implements ActionListener{
	//Field
	private JButton[][] btnArr = new JButton[5][5];		//내 빙고판
	private JButton[][] btnArr2 = new JButton[5][5];	//상대방 빈고판
	private JButton randomBtn, readyBtn;				//자동채우기버튼, 준비완료버튼
	private JLabel bingoCountLabel;						//빙고카운트출력 라벨
	private JPanel bingoPane, bingoPane2, readyPane, bingoCountPane;
	private String sendMessage;							//보낼 메세지
	private Socket socket;								//서버와 연결할 소켓
	private int myBingoCount = 0;						//내 빙고카운트
	private int opponentBingoCount = 0;					//상대방 빙고카운트
	private boolean[][] bool = new boolean[5][5];		//빙고카운트용
	private boolean turn = false;						//턴 확인
	private boolean ready = false;						//준비완료 상태 확인
	
	
	//Constructor
	public MainFrame(Socket socket){
		this.socket = socket;
		//빙고카운트용 boolean변수 초기화 (체크여부 확인)
		for(int i = 0 ; i < bool.length; i++){
			for(int j = 0 ; j < bool[i].length; j++){
				bool[i][j] = false;
			}
		}
	}
	


	//Method
	
	//기본Frame 생성하는 메소드
	public void makeFrame(){

		//메인프레임 set하기
		this.setTitle("빙고 게임");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(300, 100, 1050, 650);
		this.setLayout(null);
		

		//빙고 판 set하기
		//내 빙고판
		bingoPane = new JPanel();
		bingoPane.setBackground(Color.lightGray);
		bingoPane.setLocation(0, 0);
		bingoPane.setLayout(new GridLayout(5, 5));
		bingoPane.setSize(500, 500);
		
		//상대편 빙고판
		bingoPane2 = new JPanel();
		bingoPane2.setBackground(Color.lightGray);
		bingoPane2.setLocation(532, 0);
		bingoPane2.setLayout(new GridLayout(5, 5));
		bingoPane2.setSize(500, 500);
		
		for(int i = 0; i < btnArr.length; i++){
			for(int j = 0 ; j < btnArr[i].length; j++){
				btnArr[i][j] = new JButton("버튼");
				btnArr2[i][j] = new JButton();
				btnArr[i][j].setEnabled(false);
				btnArr[i][j].addActionListener(this);
				
				bingoPane.add(btnArr[i][j]);
				bingoPane2.add(btnArr2[i][j]);
			}
			
		}
		this.add(bingoPane2);
		this.add(bingoPane);
		
		bingoPane.setEnabled(false);
		bingoPane.setVisible(true);
		bingoPane2.setVisible(false);

		//빙고 개수 표시 패널
		bingoCountPane = new JPanel();
		bingoCountLabel = new JLabel("0 빙고 ");
		bingoCountLabel.setFont(new Font(bingoCountLabel.getText(), Font.BOLD, 35));

		bingoCountPane.setBackground(Color.lightGray);
		bingoCountPane.setSize(1035, 50);
		bingoCountPane.setLocation(0, 560);

		bingoCountPane.add(bingoCountLabel);
		this.add(bingoCountPane);
		
		
		//자동 채우기 버튼 & 준비 버튼 
		readyBtn = new JButton("준비 완료");
		readyBtn.setFont(new Font(readyBtn.getText(), Font.BOLD, 30));
		readyBtn.setBackground(Color.lightGray);
		readyBtn.setEnabled(false);
		
		readyPane = new JPanel();
		readyPane.setLayout(new GridLayout(1, 2));
		readyPane.setSize(1035, 60);
		readyPane.setLocation(0, 500);
		
		randomBtn = new JButton("자동 채우기");
		randomBtn.setFont(new Font(randomBtn.getText(), Font.BOLD, 30));
		randomBtn.setBackground(Color.lightGray);
		
		readyPane.add(randomBtn);
		readyPane.add(readyBtn);
		
		randomBtn.addActionListener(this);
		readyBtn.addActionListener(this);
		
		this.add(readyPane, BorderLayout.SOUTH);

		readyPane.setVisible(true);
		randomBtn.setVisible(true);

		//메세지 수신 쓰레드 동작
		ReceiveThread rt = new ReceiveThread(this, socket, btnArr, btnArr2, bool, bingoCountLabel, bingoPane, myBingoCount, randomBtn, readyBtn);
		rt.start();
		this.setVisible(true);
		
		//윈도우 창 x버튼 클릭시 프로그램 종료 처리
		addWindowListener(
				new WindowAdapter(){
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		// 자동 채우기 버튼 클릭시
		// 1 ~ 50 사이의 숫자를 중복되지 않게 저장
		boolean duplicated = false;
		if(e.getActionCommand().equals(randomBtn.getText())){
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					int random = (int)(Math.random() * 50) + 1;
					btnArr[i][j].setText(String.valueOf(random));
					btnArr[i][j].setFont(new Font(btnArr[i][j].getText(), Font.BOLD, 25));
					
					for(int k = 0 ; k <= i ; k++){
						if( k == i ){
							for(int l = 0; l < j ;l++){
								if(btnArr[k][l].getText().equals(String.valueOf(random))){
									duplicated = true;
									break;
								}
							}
						}else{
							for(int l = 0 ; l < 5; l++){
								if(btnArr[k][l].getText().equals(String.valueOf(random))){
									duplicated = true;
									break;
								}
							}
						}
						if(duplicated == true){
							j--;
							duplicated = false;
							break;
						}
					}
					
				}
			}
			readyBtn.setEnabled(true);
			
		}
		
		// 준비 완료 버튼
		else if(e.getActionCommand().equals(readyBtn.getText())){
			ready = true;
			SendThread st = new SendThread(this, socket, "준비완료", myBingoCount, turn);
				st.start();
			
			randomBtn.setEnabled(false);
			readyBtn.setEnabled(false);
		}
		
		// 빙고 버튼
		else{
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					if(e.getActionCommand().equals(btnArr[i][j].getText())){
						btnArr[i][j].setBackground(Color.RED);
						btnArr[i][j].setEnabled(false);
						sendMessage = btnArr[i][j].getText();
						bool[i][j] = true;
						
						//빙고 카운트 세기
						BingoCheck bc = new BingoCheck(bool,bingoCountLabel, btnArr);
						myBingoCount = bc.bingoCount();
						
						//5빙고 이상이면 승리메세지 출력 후 게임 종료
						if(myBingoCount >= 5){
							SendThread st = new SendThread(this, socket, "승리", myBingoCount, turn);
							st.start();
							SendThread st1 = new SendThread(this, socket, "빙고전달", myBingoCount, turn, btnArr);
							st1.start();
							bingoPane2.setVisible(true);
							JOptionPane.showConfirmDialog(this, "승리하셨습니다. 다시하시겠습니까?");
						}else{
							SendThread st = new SendThread(this, socket, sendMessage, myBingoCount, turn);
							st.start();
						}
					}
				}
			}
			//버튼 클릭 후 턴을 바꾸기 위해 버튼 비활성화
			for(int i = 0; i < btnArr.length; i++){
				for(int j = 0; j < btnArr[i].length; j++){
					btnArr[i][j].setEnabled(false);
				}
			}
		}
	}

	//Setters & Getters
	public JPanel getBingoPane2() {
		return bingoPane2;
	}


	public void setBingoPane2(JPanel bingoPane2) {
		this.bingoPane2 = bingoPane2;
	}
	
	
	public int getMyBingoCount() {
		return myBingoCount;
	}

	public JLabel getBingoCountLabel() {
		return bingoCountLabel;
	}

	public void setBingoCountLabel(JLabel bingoCountLabel) {
		this.bingoCountLabel = bingoCountLabel;
	}

	public boolean isReady() {
		return ready;
	}

	public void setReady(boolean ready) {
		this.ready = ready;
	}

	public void setMyBingoCount(int myBingoCount) {
		this.myBingoCount = myBingoCount;
	}

	public int getOpponentBingoCount() {
		return opponentBingoCount;
	}

	public void setOpponentBingoCount(int yourBingoCount) {
		this.opponentBingoCount = yourBingoCount;
	}

	public boolean isTurn() {
		return turn;
	}

	public void setTurn(boolean turn) {
		this.turn = turn;
	}
	
	public JButton[][] getBtnArr() {
		return btnArr;
	}

	public void setBtnArr(JButton[][] btnArr) {
		this.btnArr = btnArr;
	}
}